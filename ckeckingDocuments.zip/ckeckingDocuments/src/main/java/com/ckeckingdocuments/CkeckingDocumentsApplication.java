package com.ckeckingdocuments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CkeckingDocumentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CkeckingDocumentsApplication.class, args);
	}
}
