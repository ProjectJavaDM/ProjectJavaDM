package com.ckeckingdocuments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CkeckingdocumentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CkeckingdocumentsApplication.class, args);
	}
}
